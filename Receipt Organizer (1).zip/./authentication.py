from routes.routes import request

from flask import Blueprint, session, redirect, url_for
from abilities import flask_app_authenticator

auth = Blueprint('auth', __name__)

def auth_required(protected_routes=[]):
    def decorator():
        def decorated_view():
            if request.endpoint not in protected_routes or request.endpoint == 'static':
                return None
            return flask_app_authenticator(
                allowed_domains=None,
                allowed_users=None,
                app_title="Receptify",
                logo_path=None,  # Set to None to prevent any default icon
                custom_styles={
                    'global': {
                        'background': 'linear-gradient(135deg, #F9F9F9 0%, #ffffff 100%)',
                        'min-height': '100vh',
                        'display': 'flex',
                        'align-items': 'center',
                        'justify-content': 'center',
                        'padding': '20px'
                    },
                    'card': {
                        'text-align': 'center',
                        'padding': '2rem',
                        'background': 'white',
                        'border-radius': '20px',
                        'box-shadow': '0 4px 20px rgba(0,0,0,0.1)',
                        'max-width': '400px',
                        'width': '100%',
                        'margin': '0 auto',
                        'position': 'relative'
                    },
                    'title': {
                        'font-size': '2.5rem',
                        'font-weight': '700',
                        'color': '#A27B5C',
                        'margin-bottom': '2rem',
                        'text-align': 'center',
                        'position': 'relative'
                    },
                    'logo': {
                        'display': 'none'  # Hide any default logo
                    },
                    'button': {
                        'background': 'linear-gradient(45deg, #A27B5C, #c19b84)',
                        'border': 'none',
                        'border-radius': '50px',
                        'padding': '1rem 2rem',
                        'font-weight': '600',
                        'color': 'white',
                        'width': '100%',
                        'max-width': '300px',
                        'margin': '0 auto 1.5rem',
                        'display': 'block',
                        'box-shadow': '0 4px 15px rgba(162, 123, 92, 0.3)',
                        'cursor': 'pointer',
                        'transition': 'all 0.3s ease'
                    },
                    'button:hover': {
                        'transform': 'translateY(-2px)',
                        'box-shadow': '0 6px 20px rgba(162, 123, 92, 0.4)'
                    },
                    'google_button': {
                        'background': 'white',
                        'border': '1px solid rgba(0,0,0,0.1)',
                        'border-radius': '50px',
                        'padding': '1rem 2rem',
                        'font-weight': '600',
                        'color': '#333',
                        'width': '100%',
                        'max-width': '300px',
                        'margin': '0 auto',
                        'display': 'flex',
                        'align-items': 'center',
                        'justify-content': 'center',
                        'gap': '0.75rem',
                        'box-shadow': '0 4px 15px rgba(0,0,0,0.1)',
                        'cursor': 'pointer',
                        'transition': 'all 0.3s ease'
                    },
                    'google_button:hover': {
                        'transform': 'translateY(-2px)',
                        'box-shadow': '0 6px 20px rgba(0,0,0,0.15)'
                    }
                },
                session_expiry=None
            )()


        return decorated_view
    return decorator

@auth.route("/logout", methods=['POST'])
def logout_route():
    session.clear()
    return redirect(url_for('routes.landing_route'))