from abilities import llm
from abilities import url_for_uploaded_file
from flask import jsonify
from flask import render_template, session, Blueprint, redirect, url_for, make_response, request, flash, Response
from functools import wraps
from models import db, Receipt, User
from abilities import upload_file_to_storage
import logging
import requests
from collections import defaultdict

routes = Blueprint('routes', __name__)

def with_sidebar(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        return render_template(f.__name__.replace('_route', '.html'), with_sidebar=True)
    return decorated_function

@routes.route("/")
def landing_route():
    return render_template("landing.html", with_sidebar=False)

@routes.route("/rename_receipt/<int:receipt_id>", methods=['POST'])
def rename_receipt_route(receipt_id):
    try:
        # Get current user
        user_email = session['user']['user_email']
        user = User.query.filter_by(email=user_email).first()
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Find the receipt and verify ownership
        receipt = Receipt.query.filter_by(id=receipt_id, user_id=user.id).first()
        
        if not receipt:
            return jsonify({'error': 'Receipt not found'}), 404
        
        # Update the display name
        data = request.get_json()
        receipt.display_name = data.get('display_name', '').strip() or None
        db.session.commit()
        
        return jsonify({'success': True})
    except Exception as e:
        logging.error(f"Error renaming receipt: {str(e)}")
        return jsonify({'error': 'Error renaming receipt'}), 500

@routes.route("/home_logged_in")
def home_logged_in_route():
    # Get current user's receipts
    user_email = session['user']['user_email']
    user = User.query.filter_by(email=user_email).first()
    search_query = request.args.get('search', '').lower()
    
    if user:
        # Get all receipts for the user
        receipts = Receipt.query.filter_by(user_id=user.id).order_by(Receipt.created_at.desc()).all()
        
        # Common retail abbreviations mapping
        abbreviations = {
            'lg': 'large',
            'sm': 'small',
            'med': 'medium',
            'org': 'organic',
            'nat': 'natural',
            'choc': 'chocolate',
            'chk': 'chicken',
            'grn': 'green',
            'frz': 'frozen',
            'fsh': 'fresh',
            'wht': 'white',
            'brn': 'brown',
            'van': 'vanilla',
            'straw': 'strawberry',
            'bnls': 'boneless',
            'sknls': 'skinless',
            'xtra': 'extra',
            'reg': 'regular',
            'prem': 'premium'
        }
        
        # Filter receipts based on search query
        if search_query:
            filtered_receipts = []
            search_terms = search_query.lower().split()
            
            # Create expanded search terms including both abbreviated and full forms
            expanded_search_terms = []
            for term in search_terms:
                expanded_search_terms.append(term)
                # Add full form if term is an abbreviation
                if term in abbreviations:
                    expanded_search_terms.append(abbreviations[term])
                # Add abbreviation if term is a full form
                for abbr, full in abbreviations.items():
                    if term == full:
                        expanded_search_terms.append(abbr)
            
            for receipt in receipts:
                searchable_text = (
                    f"{receipt.store_name} "
                    f"{receipt.items_text or ''} "
                    f"{receipt.total_amount if receipt.total_amount else ''} "
                    f"{receipt.receipt_date or ''} "
                    f"{receipt.created_at.strftime('%Y-%m-%d') if receipt.created_at else ''}"
                ).lower()
                
                # Check if any of the expanded search terms match
                if any(term in searchable_text for term in expanded_search_terms):
                    filtered_receipts.append(receipt)
            receipts = filtered_receipts
        
        # Organize receipts by store
        receipts_by_store = defaultdict(list)
        for receipt in receipts:
            receipts_by_store[receipt.store_name].append(receipt)
        
        # Convert to regular dict and sort by store name
        receipts_by_store = dict(sorted(receipts_by_store.items()))
        
        return render_template(
            "home_logged_in.html",
            with_sidebar=True,
            receipts_by_store=receipts_by_store,
            total_receipts=len(receipts),
            search_query=search_query,
            all_receipts=receipts  # Pass all receipts for summary table
        )
    return render_template("home_logged_in.html", with_sidebar=True)

@routes.route("/analyze_receipt", methods=['POST'])
def analyze_receipt_route():
    if 'receipt_image' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    
    file = request.files['receipt_image']
    try:
        # Check file size before processing
        file.seek(0, 2)  # Seek to end of file
        size = file.tell()  # Get current position (file size)
        file.seek(0)  # Reset to beginning
        
        if size > 16 * 1024 * 1024:  # 16MB limit
            return jsonify({'error': 'File too large. Maximum size is 16MB'}), 413
        
        # Upload the file and get the file ID
        file_id = upload_file_to_storage(file)
        file_url = url_for_uploaded_file(file_id)
        
        # Use LLM to analyze the receipt image with enhanced prompt for better total amount detection
        response = llm(
            prompt="""Please analyze this receipt image and extract the following information carefully:

1. Store name
2. Date of issue
3. Total amount - IMPORTANT INSTRUCTIONS FOR TOTAL:
   - Look for the FINAL total amount at the bottom of the receipt
   - Common labels: 'Total', 'Total Amount', 'Amount Due', 'Balance Due', 'Grand Total'
   - Ignore subtotals, tax amounts, or any other partial totals
   - Look for the largest amount that appears after all other calculations
   - The total should be the sum of all items plus tax (if any)
   - Verify that the extracted total makes sense given the items and their prices
   - Remove any currency symbols (like $) and return only the number
   - Include exactly two decimal places
   - Make sure it's a positive number
   - Double-check that this is truly the final amount to be paid
4. Items - IMPORTANT:
   - List all items purchased with their prices
   - Include quantities if shown
   - Format as a comma-separated list
   - Include brand names when available
   - Be specific with item descriptions
   - Don't abbreviate item names
5. Check if the receipt is marked as VOID

Please be extra careful with the total amount extraction as this is critical information.
Double-check your work to ensure accuracy.""",
            response_schema={
                'type': 'object',
                'properties': {
                    'store_name': {'type': 'string', 'title': 'Store Name'},
                    'receipt_date': {'type': 'string', 'title': 'Receipt Date'},
                    'total_amount': {'type': 'number', 'title': 'Total Amount'},
                    'items_text': {'type': 'string', 'title': 'Items Text'},
                    'voided': {'type': 'boolean', 'title': 'Voided'}
                },
                'required': ['store_name', 'receipt_date', 'total_amount', 'items_text', 'voided']
            },
            image_url=file_url
        )
        
        # Log the extracted information for debugging
        logging.info(f"Extracted receipt information: {response}")
        
        return jsonify({
            'store_name': response['store_name'],
            'receipt_date': response['receipt_date'],
            'total_amount': response['total_amount'],
            'items_text': response['items_text'],
            'voided': response['voided'],
            'file_id': file_id
        })
    except Exception as e:
        logging.error(f"Error analyzing receipt: {str(e)}")
        return jsonify({'error': 'Error analyzing receipt'}), 500

@routes.route("/upload_receipt", methods=['POST'])
def upload_receipt_route():
    try:
        file_id = request.form.get('file_id')
        store_name = request.form.get('store_name')
        receipt_date = request.form.get('receipt_date')
        total_amount = request.form.get('total_amount')
        items_text = request.form.get('items_text')
        voided = request.form.get('voided') == 'true'
        
        if not file_id or not store_name:
            flash('Missing required fields', 'error')
            return redirect(url_for('routes.home_logged_in_route'))
        
        # Get the current user
        user_email = session['user']['user_email']
        user = User.query.filter_by(email=user_email).first()
        
        if not user:
            flash('User not found', 'error')
            return redirect(url_for('routes.home_logged_in_route'))
        
        # Convert total_amount to float if present
        try:
            total_amount = float(total_amount) if total_amount else None
        except ValueError:
            total_amount = None
            logging.warning(f"Could not convert total amount to float: {total_amount}")
        
        # Create new receipt record
        receipt = Receipt(
            user_id=user.id,
            store_name=store_name,
            image_id=file_id,
            receipt_date=receipt_date,
            total_amount=total_amount,
            items_text=items_text,
            voided=voided
        )
        
        db.session.add(receipt)
        db.session.commit()
        
        if voided:
            flash('Receipt uploaded successfully but marked as VOID!', 'warning')
        else:
            flash('Receipt uploaded successfully!', 'success')
    except Exception as e:
        logging.error(f"Error uploading receipt: {str(e)}")
        flash('Error uploading receipt', 'error')
    
    return redirect(url_for('routes.home_logged_in_route'))

@routes.route("/delete_receipt/<int:receipt_id>", methods=['POST'])
def delete_receipt_route(receipt_id):
    try:
        # Get current user
        user_email = session['user']['user_email']
        user = User.query.filter_by(email=user_email).first()
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Find the receipt and verify ownership
        receipt = Receipt.query.filter_by(id=receipt_id, user_id=user.id).first()
        
        if not receipt:
            return jsonify({'error': 'Receipt not found'}), 404
        
        # Delete the receipt
        db.session.delete(receipt)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Receipt deleted successfully'})
    except Exception as e:
        logging.error(f"Error deleting receipt: {str(e)}")
        return jsonify({'error': 'Error deleting receipt'}), 500

@routes.route("/toggle_void_receipt/<int:receipt_id>", methods=['POST'])
def toggle_void_receipt_route(receipt_id):
    try:
        # Get current user
        user_email = session['user']['user_email']
        user = User.query.filter_by(email=user_email).first()
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Find the receipt and verify ownership
        receipt = Receipt.query.filter_by(id=receipt_id, user_id=user.id).first()
        
        if not receipt:
            return jsonify({'error': 'Receipt not found'}), 404
        
        # Toggle void status
        receipt.voided = not receipt.voided
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f"Receipt {'voided' if receipt.voided else 'unvoided'} successfully"
        })
    except Exception as e:
        logging.error(f"Error toggling void status: {str(e)}")
        return jsonify({'error': 'Error toggling void status'}), 500

@routes.route("/files/<file_id>")
def stream_file_route(file_id):
    if 'user' not in session:
        return "Unauthorized", 401
    
    try:
        # Get current user's receipts to verify access
        user = User.query.filter_by(email=session['user']['user_email']).first()
        if not user:
            return "Unauthorized", 401
        
        # Check if the receipt belongs to the user
        receipt = Receipt.query.filter_by(image_id=file_id, user_id=user.id).first()
        if not receipt:
            return "Not found", 404
        
        # Stream the file
        file_url = url_for_uploaded_file(file_id)
        response = requests.get(file_url)
        
        if response.status_code != 200:
            return "Error loading image", 500
            
        return Response(
            response.content,
            mimetype=response.headers.get('content-type', 'image/jpeg'),
            status=200
        )
    except Exception as e:
        logging.error(f"Error streaming file: {str(e)}")
        return "Error loading image", 500