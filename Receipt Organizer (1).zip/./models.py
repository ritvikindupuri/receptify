from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)
    profile_picture = db.Column(db.String(255))
    receipts = db.relationship('Receipt', backref='user', lazy=True)

class Receipt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    store_name = db.Column(db.String(255), nullable=False)
    image_id = db.Column(db.String(255), nullable=False)
    display_name = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    receipt_date = db.Column(db.String(255), nullable=True)
    total_amount = db.Column(db.Float, nullable=True)
    items_text = db.Column(db.Text, nullable=True)
    voided = db.Column(db.Boolean, nullable=False, default=False)