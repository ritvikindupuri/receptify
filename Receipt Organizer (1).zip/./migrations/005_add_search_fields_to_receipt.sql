ALTER TABLE receipt ADD COLUMN total_amount FLOAT;
ALTER TABLE receipt ADD COLUMN items_text TEXT;